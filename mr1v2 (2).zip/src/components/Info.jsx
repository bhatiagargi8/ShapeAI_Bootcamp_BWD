import React from "react";
function Info() {
  return (
    <div className="note">
      <h1> javascript and react.js</h1>
      <p> A basic web dev React.js bootcamps</p>
    </div>
  );
}
export default Info;
